/**
 * Типы и интерфейсы
 */

/**
 * Тип для комплексного числа
 */
interface ComplexNumber {
    real: number;
    imag: number;
}

/**
 * Тип для операции с комплексными числами
 */
type ComplexOperation = 'add' | 'subtract' | 'multiply' | 'divide';

/**
 * Тип для конфигурации точек на канвасе
 */
interface CanvasPoint {
    real: number;
    imag: number;
    color?: string;
    label?: string;
}

/**
 * Класс для управления сайтом "Эволюция математики"
 */
class MathEvolution {
    // DOM элементы
    private navbar: HTMLElement | null = null;
    private hamburger: HTMLElement | null = null;
    private navLinks: HTMLElement | null = null;
    private timelineItems: NodeListOf<HTMLElement> = document.querySelectorAll('.timeline-item');
    private preloader: HTMLElement | null = null;
    private complexCanvas: HTMLCanvasElement | null = null;
    private operationCanvas: HTMLCanvasElement | null = null;
    
    // Состояние
    private currentOperation: ComplexOperation = 'add';
    private animationFrameId: number | null = null;
    private statsCounted: boolean = false;
    private isInitialized: boolean = false;

    /**
     * Конструктор класса
     */
    constructor() {
        // Инициализируем ТОЛЬКО свойства, которые не зависят от DOM
        // ВСЕ остальное инициализируем в init()
    }

    /**
     * Инициализация приложения
     */
    public init(): void {
        if (this.isInitialized) return;
        
        this.isInitialized = true;
        
        // Находим элементы DOM
        this.findElements();
        
        // Добавляем обработчики событий
        this.addEventListeners();
        
        // Инициализируем анимации с задержкой
        setTimeout(() => {
            this.initializeAnimations();
            this.initializeComplexPlane();
            this.initializeOperationVisualizer();
            this.animateStats();
        }, 100);
    }

    /**
     * Поиск элементов в DOM
     */
    private findElements(): void {
        this.navbar = document.querySelector('.navbar');
        this.hamburger = document.querySelector('.hamburger');
        this.navLinks = document.querySelector('.nav-links');
        this.timelineItems = document.querySelectorAll('.timeline-item');
        this.preloader = document.querySelector('.preloader');
        this.complexCanvas = document.getElementById('complexCanvas') as HTMLCanvasElement | null;
        this.operationCanvas = document.getElementById('operationCanvas') as HTMLCanvasElement | null;
    }

    /**
     * Добавление обработчиков событий
     */
    private addEventListeners(): void {
        // Прелоадер - УЛУЧШЕННАЯ ВЕРСИЯ
        window.addEventListener('load', () => {
            this.hidePreloader();
        });

        // Если страница уже загружена, скрываем прелоадер сразу
        if (document.readyState === 'complete') {
            this.hidePreloader();
        }

        // Навигация при скролле
        window.addEventListener('scroll', () => this.handleScroll());

        // Меню-гамбургер
        if (this.hamburger) {
            this.hamburger.addEventListener('click', () => this.toggleMenu());
        }

        // Якорные ссылки
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', (e: Event) => this.handleAnchorClick(e, anchor));
        });

        // Операции с комплексными числами
        document.querySelectorAll('.operation-btn').forEach(btn => {
            btn.addEventListener('click', (e: Event) => this.setOperation(e));
        });

        // Кнопка калькулятора
        const calculateBtn = document.getElementById('calculateBtn');
        if (calculateBtn) {
            calculateBtn.addEventListener('click', () => this.calculateComplex());
        }

        // Форма контактов
        const contactForm = document.getElementById('contactForm');
        if (contactForm) {
            contactForm.addEventListener('submit', (e: Event) => this.handleSubmitForm(e));
        }
    }

    /**
     * Скрытие прелоадера
     */
    private hidePreloader(): void {
        if (this.preloader) {
            // Добавляем класс для анимации
            this.preloader.classList.add('hidden');
            
            // Удаляем элемент из DOM через 1 секунду для оптимизации
            setTimeout(() => {
                if (this.preloader && this.preloader.parentNode) {
                    this.preloader.parentNode.removeChild(this.preloader);
                }
            }, 1000);
        }
    }

    /**
     * Обработка скролла
     */
    private handleScroll(): void {
        // Эффект скролла для навбара
        if (this.navbar && window.scrollY > 50) {
            this.navbar.classList.add('scrolled');
        } else if (this.navbar) {
            this.navbar.classList.remove('scrolled');
        }

        // Анимация таймлайна
        this.animateTimeline();

        // Анимация статистики
        if (!this.statsCounted && window.scrollY > 200) {
            this.animateStats();
            this.statsCounted = true;
        }
    }

    /**
     * Анимация таймлайна
     */
    private animateTimeline(): void {
        Array.from(this.timelineItems).forEach(item => {
            const position = item.getBoundingClientRect().top;
            const screenPosition = window.innerHeight / 1.3;

            if (position < screenPosition) {
                item.classList.add('visible');
            }
        });
    }

    /**
     * Переключение меню
     */
    private toggleMenu(): void {
        if (this.navLinks && this.hamburger) {
            this.navLinks.classList.toggle('active');
            this.hamburger.classList.toggle('active');
        }
    }

    /**
     * Обработка клика по якорной ссылке
     */
    private handleAnchorClick(e: Event, anchor: Element): void {
        e.preventDefault();
        const href = anchor.getAttribute('href');

        if (!href || !href.startsWith('#')) return;

        const targetElement = document.querySelector(href);
        if (targetElement) {
            const elementRect = targetElement.getBoundingClientRect();
            const elementPosition = elementRect.top;
            const offsetPosition = elementPosition + window.pageYOffset - 80;

            window.scrollTo({
                top: offsetPosition,
                behavior: 'smooth'
            });
        }

        if (this.navLinks && this.hamburger) {
            this.navLinks.classList.remove('active');
            this.hamburger.classList.remove('active');
        }
    }

    /**
     * Установка операции
     */
    private setOperation(e: Event): void {
        const target = e.target as HTMLElement;

        document.querySelectorAll('.operation-btn').forEach(btn => {
            if (btn instanceof HTMLElement) {
                btn.classList.remove('active');
            }
        });

        if (target instanceof HTMLElement) {
            target.classList.add('active');
            const op = target.getAttribute('data-op');
            if (op && (op === 'add' || op === 'subtract' || op === 'multiply' || op === 'divide')) {
                this.currentOperation = op as ComplexOperation;
            }
        }
    }

    /**
     * Вычисление комплексных чисел
     */
    private calculateComplex(): void {
        const real1Input = document.getElementById('real1') as HTMLInputElement | null;
        const imag1Input = document.getElementById('imag1') as HTMLInputElement | null;
        const real2Input = document.getElementById('real2') as HTMLInputElement | null;
        const imag2Input = document.getElementById('imag2') as HTMLInputElement | null;

        if (!real1Input || !imag1Input || !real2Input || !imag2Input) {
            console.error('Не все поля ввода найдены');
            return;
        }

        const real1 = parseFloat(real1Input.value) || 0;
        const imag1 = parseFloat(imag1Input.value) || 0;
        const real2 = parseFloat(real2Input.value) || 0;
        const imag2 = parseFloat(imag2Input.value) || 0;

        const z1: ComplexNumber = { real: real1, imag: imag1 };
        const z2: ComplexNumber = { real: real2, imag: imag2 };

        let result: ComplexNumber;

        switch (this.currentOperation) {
            case 'add':
                result = this.addComplex(z1, z2);
                break;
            case 'subtract':
                result = this.subtractComplex(z1, z2);
                break;
            case 'multiply':
                result = this.multiplyComplex(z1, z2);
                break;
            case 'divide':
                result = this.divideComplex(z1, z2);
                break;
            default:
                result = z1;
        }

        this.displayResult(result);
        this.updateVisualization(z1, z2, result);
    }

    /**
     * Сложение комплексных чисел
     */
    private addComplex(z1: ComplexNumber, z2: ComplexNumber): ComplexNumber {
        return {
            real: z1.real + z2.real,
            imag: z1.imag + z2.imag
        };
    }

    /**
     * Вычитание комплексных чисел
     */
    private subtractComplex(z1: ComplexNumber, z2: ComplexNumber): ComplexNumber {
        return {
            real: z1.real - z2.real,
            imag: z1.imag - z2.imag
        };
    }

    /**
     * Умножение комплексных чисел
     */
    private multiplyComplex(z1: ComplexNumber, z2: ComplexNumber): ComplexNumber {
        return {
            real: z1.real * z2.real - z1.imag * z2.imag,
            imag: z1.real * z2.imag + z1.imag * z2.real
        };
    }

    /**
     * Деление комплексных чисел
     */
    private divideComplex(z1: ComplexNumber, z2: ComplexNumber): ComplexNumber {
        const denominator = z2.real * z2.real + z2.imag * z2.imag;

        if (denominator === 0) {
            console.error('Деление на ноль');
            return { real: 0, imag: 0 };
        }

        return {
            real: (z1.real * z2.real + z1.imag * z2.imag) / denominator,
            imag: (z1.imag * z2.real - z1.real * z2.imag) / denominator
        };
    }

    /**
     * Отображение результата
     */
    private displayResult(result: ComplexNumber): void {
        const resultText = document.getElementById('resultText');
        if (!resultText) return;

        const sign = result.imag >= 0 ? '+' : '-';
        resultText.textContent = `${result.real.toFixed(2)} ${sign} ${Math.abs(result.imag).toFixed(2)}i`;
    }

    /**
     * Обработка отправки формы
     */
    private handleSubmitForm(e: Event): void {
        e.preventDefault();
        const form = e.target as HTMLFormElement;
        const formData = new FormData(form);

        const formObject: Record<string, string> = {};
        formData.forEach((value, key) => {
            formObject[key] = value.toString();
        });

        console.log('Form submitted:', formObject);

        alert('Сообщение отправлено успешно!');
        form.reset();
    }

    /**
     * Инициализация анимаций
     */
    private initializeAnimations(): void {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate');
                }
            });
        }, observerOptions);

        document.querySelectorAll('.complex-card, .gallery-item').forEach(item => {
            observer.observe(item);
        });
    }

    /**
     * Инициализация комплексной плоскости
     */
    private initializeComplexPlane(): void {
        if (!this.complexCanvas) return;

        const ctx = this.complexCanvas.getContext('2d');
        if (!ctx) return;

        const rect = this.complexCanvas.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) {
            console.warn('Canvas не видим или имеет нулевой размер');
            return;
        }

        const width = this.complexCanvas.width = Math.floor(rect.width);
        const height = this.complexCanvas.height = Math.floor(rect.height);

        // Очистка и настройка
        ctx.clearRect(0, 0, width, height);

        // Рисуем оси
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
        ctx.lineWidth = 2;

        // Горизонтальная ось (действительная)
        ctx.beginPath();
        ctx.moveTo(0, height / 2);
        ctx.lineTo(width, height / 2);
        ctx.stroke();

        // Вертикальная ось (мнимая)
        ctx.beginPath();
        ctx.moveTo(width / 2, 0);
        ctx.lineTo(width / 2, height);
        ctx.stroke();

        // Рисуем комплексные числа с анимацией
        this.animateComplexPoints(ctx, width, height);
    }

    /**
     * Анимация точек на комплексной плоскости
     */
    private animateComplexPoints(ctx: CanvasRenderingContext2D, width: number, height: number): void {
        const centerX = width / 2;
        const centerY = height / 2;
        const points: ComplexNumber[] = [
            { real: 100, imag: 50 },
            { real: -80, imag: 120 },
            { real: 150, imag: -80 },
            { real: -120, imag: -100 }
        ];

        let frame = 0;
        const animate = (): void => {
            if (!this.complexCanvas || this.complexCanvas.width === 0) {
                return;
            }

            ctx.clearRect(0, 0, width, height);

            // Перерисовываем оси
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(0, centerY);
            ctx.lineTo(width, centerY);
            ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(centerX, 0);
            ctx.lineTo(centerX, height);
            ctx.stroke();

            // Рисуем точки
            points.forEach((point, index) => {
                const angle = frame * 0.02 + index * Math.PI / 2;
                const radius = 80 + Math.sin(frame * 0.05 + index) * 30;

                const x = centerX + point.real * Math.cos(angle) - point.imag * Math.sin(angle);
                const y = centerY + point.real * Math.sin(angle) + point.imag * Math.cos(angle);

                ctx.beginPath();
                ctx.arc(x, y, 8, 0, Math.PI * 2);
                ctx.fillStyle = `hsl(${index * 60}, 70%, 60%)`;
                ctx.fill();

                ctx.strokeStyle = 'white';
                ctx.lineWidth = 2;
                ctx.stroke();

                // Линия к центру
                ctx.beginPath();
                ctx.moveTo(centerX, centerY);
                ctx.lineTo(x, y);
                ctx.strokeStyle = `hsl(${index * 60}, 50%, 50%)`;
                ctx.lineWidth = 1;
                ctx.stroke();
            });

            frame++;
            this.animationFrameId = requestAnimationFrame(animate);
        };

        animate();
    }

    /**
     * Инициализация визуализатора операций
     */
    private initializeOperationVisualizer(): void {
        if (!this.operationCanvas) return;

        const ctx = this.operationCanvas.getContext('2d');
        if (!ctx) return;

        const rect = this.operationCanvas.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) {
            console.warn('Operation Canvas не видим или имеет нулевой размер');
            return;
        }

        const width = this.operationCanvas.width = Math.floor(rect.width);
        const height = this.operationCanvas.height = Math.floor(rect.height);

        ctx.clearRect(0, 0, width, height);

        // Рисуем сетку
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
        ctx.lineWidth = 1;

        for (let i = 0; i < width; i += 20) {
            ctx.beginPath();
            ctx.moveTo(i, 0);
            ctx.lineTo(i, height);
            ctx.stroke();
        }

        for (let i = 0; i < height; i += 20) {
            ctx.beginPath();
            ctx.moveTo(0, i);
            ctx.lineTo(width, i);
            ctx.stroke();
        }
    }

    /**
     * Обновление визуализации
     */
    private updateVisualization(z1: ComplexNumber, z2: ComplexNumber, result: ComplexNumber): void {
        if (!this.operationCanvas) return;

        const ctx = this.operationCanvas.getContext('2d');
        if (!ctx) return;

        const rect = this.operationCanvas.getBoundingClientRect();
        const width = Math.floor(rect.width);
        const height = Math.floor(rect.height);
        const centerX = width / 2;
        const centerY = height / 2;
        const scale = 30;

        ctx.clearRect(0, 0, width, height);

        // Перерисовываем сетку
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
        ctx.lineWidth = 1;

        for (let i = 0; i < width; i += 20) {
            ctx.beginPath();
            ctx.moveTo(i, 0);
            ctx.lineTo(i, height);
            ctx.stroke();
        }

        for (let i = 0; i < height; i += 20) {
            ctx.beginPath();
            ctx.moveTo(0, i);
            ctx.lineTo(width, i);
            ctx.stroke();
        }

        // Рисуем оси
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.5)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(0, centerY);
        ctx.lineTo(width, centerY);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(centerX, 0);
        ctx.lineTo(centerX, height);
        ctx.stroke();

        // Рисуем комплексные числа
        const drawPoint = (z: ComplexNumber, color: string, label: string): void => {
            const x = centerX + z.real * scale;
            const y = centerY - z.imag * scale;

            ctx.beginPath();
            ctx.arc(x, y, 8, 0, Math.PI * 2);
            ctx.fillStyle = color;
            ctx.fill();

            ctx.strokeStyle = 'white';
            ctx.lineWidth = 2;
            ctx.stroke();

            ctx.fillStyle = 'white';
            ctx.font = '14px Arial';
            ctx.fillText(label, x + 15, y - 15);

            // Линия к центру
            ctx.beginPath();
            ctx.moveTo(centerX, centerY);
            ctx.lineTo(x, y);
            ctx.strokeStyle = color;
            ctx.lineWidth = 2;
            ctx.stroke();
        };

        drawPoint(z1, '#6366f1', 'z₁');
        drawPoint(z2, '#8b5cf6', 'z₂');
        drawPoint(result, '#10b981', 'Результат');
    }

    /**
     * Анимация статистики
     */
    private animateStats(): void {
        document.querySelectorAll('.stat-number').forEach(stat => {
            const target = parseInt(stat.getAttribute('data-count') || '0');
            const duration = 2000;
            const start = 0;
            const increment = target / (duration / 16);

            let current = start;
            const animate = (): void => {
                current += increment;
                if (current < target) {
                    stat.textContent = Math.floor(current).toString();
                    requestAnimationFrame(animate);
                } else {
                    stat.textContent = target.toString();
                }
            };

            animate();
        });
    }
}

/**
 * Инициализация приложения после загрузки DOM
 */
document.addEventListener('DOMContentLoaded', () => {
    try {
        // Создаем экземпляр приложения
        const app = new MathEvolution();
        
        // Инициализируем приложение
        app.init();
        
        console.log('✅ MathEvolution initialized successfully!');
    } catch (error) {
        console.error('❌ Error initializing MathEvolution:', error);
        
        // Если есть ошибка, всё равно скрываем прелоадер
        const preloader = document.querySelector('.preloader');
        if (preloader) {
            preloader.classList.add('hidden');
            setTimeout(() => {
                if (preloader.parentNode) {
                    preloader.parentNode.removeChild(preloader);
                }
            }, 1000);
        }
    }
});