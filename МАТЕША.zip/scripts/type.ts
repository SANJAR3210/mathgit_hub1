/**
 * Тип для комплексного числа
 */
export interface ComplexNumber {
    real: number;
    imag: number;
}

/**
 * Тип для элемента таймлайна
 */
export interface TimelineItem {
    element: HTMLElement;
    position: number;
}

/**
 * Тип для статистики
 */
export interface StatItem {
    element: HTMLElement;
    target: number;
    current: number;
}

/**
 * Тип для настроек анимации
 */
export interface AnimationOptions {
    duration: number;
    increment: number;
}

/**
 * Тип для канвас контекста
 */
export type CanvasContext = CanvasRenderingContext2D | null;

/**
 * Тип для операции с комплексными числами
 */
export type ComplexOperation = 'add' | 'subtract' | 'multiply' | 'divide';

/**
 * Тип для конфигурации точек на канвасе
 */
export interface CanvasPoint {
    real: number;
    imag: number;
    color?: string;
    label?: string;
}