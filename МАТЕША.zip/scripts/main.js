// Класс для управления сайтом
class MathEvolution {
    constructor() {
        this.navbar = null;
        this.hamburger = null;
        this.navLinks = null;
        this.timelineItems = [];
        this.preloader = null;
        this.complexCanvas = null;
        this.operationCanvas = null;
        this.currentOperation = 'add';
        this.animationFrameId = null;
        this.statsCounted = false;

        // Инициализация
        this.init();
    }

    init() {
        // Находим элементы
        this.navbar = document.querySelector('.navbar');
        this.hamburger = document.querySelector('.hamburger');
        this.navLinks = document.querySelector('.nav-links');
        this.timelineItems = document.querySelectorAll('.timeline-item');
        this.preloader = document.querySelector('.preloader');
        this.complexCanvas = document.getElementById('complexCanvas');
        this.operationCanvas = document.getElementById('operationCanvas');

        // Добавляем обработчики событий
        this.addEventListeners();

        // Инициализируем анимации с задержкой
        setTimeout(() => {
            this.initializeAnimations();
            this.initializeComplexPlane();
            this.initializeOperationVisualizer();
            this.animateStats();
        }, 100);
    }

    addEventListeners() {
        // Прелоадер
        window.addEventListener('load', () => {
            setTimeout(() => {
                if (this.preloader) {
                    this.preloader.classList.add('hidden');
                }
            }, 500);
        });

        // Навигация
        window.addEventListener('scroll', () => this.handleScroll());

        // Меню-гамбургер
        if (this.hamburger) {
            this.hamburger.addEventListener('click', () => this.toggleMenu());
        }

        // Якорные ссылки
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', (e) => this.handleAnchorClick(e, anchor));
        });

        // Операции с комплексными числами
        document.querySelectorAll('.operation-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.setOperation(e));
        });

        // Кнопка калькулятора
        const calculateBtn = document.getElementById('calculateBtn');
        if (calculateBtn) {
            calculateBtn.addEventListener('click', () => this.calculateComplex());
        }

        // Форма контактов
        const contactForm = document.getElementById('contactForm');
        if (contactForm) {
            contactForm.addEventListener('submit', (e) => this.handleSubmitForm(e));
        }
    }

    handleScroll() {
        // Эффект скролла для навбара
        if (this.navbar && window.scrollY > 50) {
            this.navbar.classList.add('scrolled');
        } else if (this.navbar) {
            this.navbar.classList.remove('scrolled');
        }

        // Анимация таймлайна
        this.timelineItems.forEach(item => {
            const position = item.getBoundingClientRect().top;
            const screenPosition = window.innerHeight / 1.3;

            if (position < screenPosition) {
                item.classList.add('visible');
            }
        });

        // Анимация статистики
        if (!this.statsCounted && window.scrollY > 200) {
            this.animateStats();
            this.statsCounted = true;
        }
    }

    toggleMenu() {
        if (this.navLinks && this.hamburger) {
            this.navLinks.classList.toggle('active');
            this.hamburger.classList.toggle('active');
        }
    }

    handleAnchorClick(e, anchor) {
        e.preventDefault();
        const href = anchor.getAttribute('href');

        if (!href || !href.startsWith('#')) return;

        const targetElement = document.querySelector(href);
        if (targetElement) {
            const elementRect = targetElement.getBoundingClientRect();
            const elementPosition = elementRect.top;
            const offsetPosition = elementPosition + window.pageYOffset - 80;

            window.scrollTo({
                top: offsetPosition,
                behavior: 'smooth'
            });
        }

        if (this.navLinks && this.hamburger) {
            this.navLinks.classList.remove('active');
            this.hamburger.classList.remove('active');
        }
    }

    setOperation(e) {
        const target = e.target;

        document.querySelectorAll('.operation-btn').forEach(btn => {
            btn.classList.remove('active');
        });

        if (target) {
            target.classList.add('active');
            this.currentOperation = target.getAttribute('data-op') || 'add';
        }
    }

    calculateComplex() {
        const real1Input = document.getElementById('real1');
        const imag1Input = document.getElementById('imag1');
        const real2Input = document.getElementById('real2');
        const imag2Input = document.getElementById('imag2');

        if (!real1Input || !imag1Input || !real2Input || !imag2Input) {
            console.error('Не все поля ввода найдены');
            return;
        }

        const real1 = parseFloat(real1Input.value) || 0;
        const imag1 = parseFloat(imag1Input.value) || 0;
        const real2 = parseFloat(real2Input.value) || 0;
        const imag2 = parseFloat(imag2Input.value) || 0;

        const z1 = { real: real1, imag: imag1 };
        const z2 = { real: real2, imag: imag2 };

        let result;

        switch (this.currentOperation) {
            case 'add':
                result = this.addComplex(z1, z2);
                break;
            case 'subtract':
                result = this.subtractComplex(z1, z2);
                break;
            case 'multiply':
                result = this.multiplyComplex(z1, z2);
                break;
            case 'divide':
                result = this.divideComplex(z1, z2);
                break;
            default:
                result = z1;
        }

        this.displayResult(result);
        this.updateVisualization(z1, z2, result);
    }

    addComplex(z1, z2) {
        return {
            real: z1.real + z2.real,
            imag: z1.imag + z2.imag
        };
    }

    subtractComplex(z1, z2) {
        return {
            real: z1.real - z2.real,
            imag: z1.imag - z2.imag
        };
    }

    multiplyComplex(z1, z2) {
        return {
            real: z1.real * z2.real - z1.imag * z2.imag,
            imag: z1.real * z2.imag + z1.imag * z2.real
        };
    }

    divideComplex(z1, z2) {
        const denominator = z2.real * z2.real + z2.imag * z2.imag;

        if (denominator === 0) {
            console.error('Деление на ноль');
            return { real: 0, imag: 0 };
        }

        return {
            real: (z1.real * z2.real + z1.imag * z2.imag) / denominator,
            imag: (z1.imag * z2.real - z1.real * z2.imag) / denominator
        };
    }

    displayResult(result) {
        const resultText = document.getElementById('resultText');
        if (!resultText) return;

        const sign = result.imag >= 0 ? '+' : '-';
        resultText.textContent = `${result.real.toFixed(2)} ${sign} ${Math.abs(result.imag).toFixed(2)}i`;
    }

    handleSubmitForm(e) {
        e.preventDefault();
        const form = e.target;
        const formData = new FormData(form);

        const formObject = {};
        formData.forEach((value, key) => {
            formObject[key] = value.toString();
        });

        console.log('Form submitted:', formObject);

        alert('Сообщение отправлено успешно!');
        form.reset();
    }

    initializeAnimations() {
        // Анимация появления элементов при прокрутке
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate');
                }
            });
        }, observerOptions);

        document.querySelectorAll('.complex-card, .gallery-item').forEach(item => {
            observer.observe(item);
        });
    }

    initializeComplexPlane() {
        if (!this.complexCanvas) return;

        const ctx = this.complexCanvas.getContext('2d');
        if (!ctx) return;

        const rect = this.complexCanvas.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) {
            console.warn('Canvas не видим или имеет нулевой размер');
            return;
        }

        const width = this.complexCanvas.width = Math.floor(rect.width);
        const height = this.complexCanvas.height = Math.floor(rect.height);

        // Очистка и настройка
        ctx.clearRect(0, 0, width, height);

        // Рисуем оси
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
        ctx.lineWidth = 2;

        // Горизонтальная ось (действительная)
        ctx.beginPath();
        ctx.moveTo(0, height / 2);
        ctx.lineTo(width, height / 2);
        ctx.stroke();

        // Вертикальная ось (мнимая)
        ctx.beginPath();
        ctx.moveTo(width / 2, 0);
        ctx.lineTo(width / 2, height);
        ctx.stroke();

        // Рисуем комплексные числа с анимацией
        this.animateComplexPoints(ctx, width, height);
    }

    animateComplexPoints(ctx, width, height) {
        const centerX = width / 2;
        const centerY = height / 2;
        const points = [
            { real: 100, imag: 50 },
            { real: -80, imag: 120 },
            { real: 150, imag: -80 },
            { real: -120, imag: -100 }
        ];

        let frame = 0;
        const animate = () => {
            if (!this.complexCanvas || this.complexCanvas.width === 0) {
                return;
            }

            ctx.clearRect(0, 0, width, height);

            // Перерисовываем оси
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(0, centerY);
            ctx.lineTo(width, centerY);
            ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(centerX, 0);
            ctx.lineTo(centerX, height);
            ctx.stroke();

            // Рисуем точки
            points.forEach((point, index) => {
                const angle = frame * 0.02 + index * Math.PI / 2;
                const radius = 80 + Math.sin(frame * 0.05 + index) * 30;

                const x = centerX + point.real * Math.cos(angle) - point.imag * Math.sin(angle);
                const y = centerY + point.real * Math.sin(angle) + point.imag * Math.cos(angle);

                ctx.beginPath();
                ctx.arc(x, y, 8, 0, Math.PI * 2);
                ctx.fillStyle = `hsl(${index * 60}, 70%, 60%)`;
                ctx.fill();

                ctx.strokeStyle = 'white';
                ctx.lineWidth = 2;
                ctx.stroke();

                // Линия к центру
                ctx.beginPath();
                ctx.moveTo(centerX, centerY);
                ctx.lineTo(x, y);
                ctx.strokeStyle = `hsl(${index * 60}, 50%, 50%)`;
                ctx.lineWidth = 1;
                ctx.stroke();
            });

            frame++;
            this.animationFrameId = requestAnimationFrame(animate);
        };

        animate();
    }

    initializeOperationVisualizer() {
        if (!this.operationCanvas) return;

        const ctx = this.operationCanvas.getContext('2d');
        if (!ctx) return;

        const rect = this.operationCanvas.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) {
            console.warn('Operation Canvas не видим или имеет нулевой размер');
            return;
        }

        const width = this.operationCanvas.width = Math.floor(rect.width);
        const height = this.operationCanvas.height = Math.floor(rect.height);

        ctx.clearRect(0, 0, width, height);

        // Рисуем сетку
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
        ctx.lineWidth = 1;

        for (let i = 0; i < width; i += 20) {
            ctx.beginPath();
            ctx.moveTo(i, 0);
            ctx.lineTo(i, height);
            ctx.stroke();
        }

        for (let i = 0; i < height; i += 20) {
            ctx.beginPath();
            ctx.moveTo(0, i);
            ctx.lineTo(width, i);
            ctx.stroke();
        }
    }

    updateVisualization(z1, z2, result) {
        if (!this.operationCanvas) return;

        const ctx = this.operationCanvas.getContext('2d');
        if (!ctx) return;

        const rect = this.operationCanvas.getBoundingClientRect();
        const width = Math.floor(rect.width);
        const height = Math.floor(rect.height);
        const centerX = width / 2;
        const centerY = height / 2;
        const scale = 30;

        ctx.clearRect(0, 0, width, height);

        // Перерисовываем сетку
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
        ctx.lineWidth = 1;

        for (let i = 0; i < width; i += 20) {
            ctx.beginPath();
            ctx.moveTo(i, 0);
            ctx.lineTo(i, height);
            ctx.stroke();
        }

        for (let i = 0; i < height; i += 20) {
            ctx.beginPath();
            ctx.moveTo(0, i);
            ctx.lineTo(width, i);
            ctx.stroke();
        }

        // Рисуем оси
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.5)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(0, centerY);
        ctx.lineTo(width, centerY);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(centerX, 0);
        ctx.lineTo(centerX, height);
        ctx.stroke();

        // Рисуем комплексные числа
        const drawPoint = (z, color, label) => {
            const x = centerX + z.real * scale;
            const y = centerY - z.imag * scale;

            ctx.beginPath();
            ctx.arc(x, y, 8, 0, Math.PI * 2);
            ctx.fillStyle = color;
            ctx.fill();

            ctx.strokeStyle = 'white';
            ctx.lineWidth = 2;
            ctx.stroke();

            ctx.fillStyle = 'white';
            ctx.font = '14px Arial';
            ctx.fillText(label, x + 15, y - 15);

            // Линия к центру
            ctx.beginPath();
            ctx.moveTo(centerX, centerY);
            ctx.lineTo(x, y);
            ctx.strokeStyle = color;
            ctx.lineWidth = 2;
            ctx.stroke();
        };

        drawPoint(z1, '#6366f1', 'z₁');
        drawPoint(z2, '#8b5cf6', 'z₂');
        drawPoint(result, '#10b981', 'Результат');
    }

    animateStats() {
        document.querySelectorAll('.stat-number').forEach(stat => {
            const target = parseInt(stat.getAttribute('data-count'));
            const duration = 2000;
            const start = 0;
            const increment = target / (duration / 16);

            let current = start;
            const animate = () => {
                current += increment;
                if (current < target) {
                    stat.textContent = Math.floor(current);
                    requestAnimationFrame(animate);
                } else {
                    stat.textContent = target;
                }
            };

            animate();
        });
    }
}

// Инициализация при загрузке
document.addEventListener('DOMContentLoaded', () => {
    new MathEvolution();
    console.log('MathEvolution initialized successfully!');
});